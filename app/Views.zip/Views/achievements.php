<main>
    <!-- Banner Section -->
    <section class="banner-section">
        <?php if (!empty($banner)): ?>
        <img src="<?= base_url('uploads/banner_images/' . $banner['desktop_image']); ?>" class="img-fluid deskTopImg"
            alt="<?= esc($banner['title']); ?>">
        <img src="<?= base_url('uploads/banner_images/' . $banner['mobile_image']); ?>" class="img-fluid mobImg w100"
            alt="Banner image">
        <div class="bannerTitle">
            <h1>Sir Mutha School</h1>
            <p>A unit of the madras seva sadan</p>
        </div>
        <div class="banner-subTitle">
            <h2><?= esc($banner['title']); ?></h2>
        </div>
        <?php endif; ?>
        </div>
    </section>
    <!-- Banner Section -->

    <!-- Section Menus -->
    <section class="container-space innerMenus-sec">
        <div class="innerMenus">
            <ul class="lessMenus">
                <li><a href="#" class="active">Gallery</a></li>
            </ul>
        </div>
        <div class="pageTitleLine col-lg-8 m-auto">
            <hr>
            <img src="<?= base_url('images/title-logo.svg') ?>" alt="Sir Mutha Logo">
            <hr>
        </div>
        <div class="sectionTitle-white col-lg-10 m-auto">
            <h3>Sir Mutha <span> Gallery</span></h3>
            <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                fugiat nulla pariatur</h6>
        </div>
    </section>
    <!-- Section Menus -->

    <!-- Tab View Sections -->
    <section class="container-space blueBg-Sec wave-bottom-img ptb-80">
        <div class="Panel achievements">
            <nav>
                <ul class="Tabs">
                    <li class="Tabs__tab active Tab" data-tab="1"><span>Academics</span></li>
                    <li class="Tabs__tab Tab" data-tab="2"><span>Sports</span></li>
                    <li class="Tabs__tab Tab" data-tab="3"><span>Inter School</span></li>
                    <li class="Tabs__tab Tab" data-tab="4"><span>Literary & Arts</span></li>
                    <li class="Tabs__tab Tab" data-tab="5"><span>Teachers</span></li>
                    <li class="Tabs__presentation-slider" role="presentation"></li>
                </ul>
            </nav>
            <div class="Panel-body">
                <div class="tab-content" id="tab-1">
                    <!-- <div class="row w100 m-0">
                        <div class="col-12 col-md-6 col-lg-6 col-xl-6 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-5.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-6 col-xl-6 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-6.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                    </div> -->
                    <div class="row w100 m-0">
                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-3.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-4.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-4.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-3.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-4.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-4.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" id="tab-2" style="display: none;">
                    <div class="row w100 m-0">
                        <div class="col-lg-6 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-5.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                        <div class="col-lg-6 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-6.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                    </div>
                    <div class="row w100 m-0">
                        <div class="col-lg-4 p-0">
                            <div class="gallery-imgs">
                                <div class="gallery-imgItem1">
                                    <img src="<?= base_url('images/gallery/gallery-1.png') ?>" class="img-fluid w100"
                                        alt="Sir Gallery Images">
                                </div>
                                <div class="gallery-imgItem2">
                                    <img src="<?= base_url('images/gallery/gallery-2.png') ?>" class="img-fluid w100"
                                        alt="Sir Gallery Images">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-3.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                        <div class="col-lg-4 p-0">
                            <div class="gallery-imgs">
                                <img src="<?= base_url('images/gallery/gallery-4.png') ?>" class="img-fluid w100"
                                    alt="Sir Gallery Images">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-content" id="tab-3" style="display: none;">
                    <h1>tab 3</h1>
                </div>
                <div class="tab-content" id="tab-4" style="display: none;">
                    <h1>tab 4</h1>
                </div>
                <div class="tab-content" id="tab-5" style="display: none;">
                    <h1>tab 5</h1>
                </div>
            </div>
        </div>
    </section>
    <!-- Tab View Sections -->