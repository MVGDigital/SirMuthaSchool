<meta charset="utf-8" />
<title><?= isset($title) ? esc($title) : 'Sir Mutha School - Admin' ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
<meta content="" name="author" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<!-- App favicon -->
<link rel="shortcut icon" href="<?= base_url('/images/favicon.png') ?>">
<script>
setTimeout(function() {
    var successAlerts = document.querySelectorAll('.alert-success');
    successAlerts.forEach(function(alert) {
        alert.style.display = 'none';
    });
}, 5000);

setTimeout(function() {
    var dangerAlerts = document.querySelectorAll('.alert-danger');
    dangerAlerts.forEach(function(alert) {
        alert.style.display = 'none';
    });
}, 5000);
</script>