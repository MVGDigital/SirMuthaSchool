<main>
    <!-- Banner Section -->
    <section class="banner-section">
        <?php if (!empty($banner)): ?>
        <img src="<?= base_url('uploads/banner_images/' . $banner['desktop_image']); ?>" class="img-fluid deskTopImg"
            alt="<?= esc($banner['title']); ?>">
        <img src="<?= base_url('uploads/banner_images/' . $banner['mobile_image']); ?>" class="img-fluid mobImg w100"
            alt="Banner image">
        <div class="bannerTitle">
            <h1>Sir Mutha School</h1>
            <p>A unit of the madras seva sadan</p>
        </div>
        <div class="banner-subTitle">
            <h2><?= esc($banner['title']); ?></h2>
        </div>
        <?php endif; ?>
        </div>
    </section>
    <!-- Banner Section -->

    <!-- Section Menus -->
    <section class="container-space innerMenus-sec">
        <div class="innerMenus">
            <ul>
                <li><a href="<?= base_url('statutory#aboutcbse') ?>" class="active">Compliance Details</a></li>
                <li><a href="<?= base_url('statutory#guidelines') ?>">Guidelines for parents</a></li>
                <li><a href="<?= base_url('statutory#guidelines') ?>">Attendence & Leave Policy</a></li>
                <li><a href="<?= base_url('statutory#aboutcbse') ?>">Code of Conduct</a></li>
                <li><a href="<?= base_url('statutory#aboutcbse') ?>">Rules & Regulations</a></li>
                <li><a href="<?= base_url('statutory#aboutcbse') ?>">Child Support Policy</a></li>
            </ul>
        </div>
        <div class="pageTitleLine col-lg-8 m-auto">
            <hr>
            <img src="<?= base_url('images/title-logo.svg') ?>" alt="Sir Mutha Logo">
            <hr>
        </div>
        <div class="sectionTitle-white col-lg-10 m-auto withYellowBtn">
            <h3>Compliance <span>Details</span></h3>
            <h6>Students are prohibited from bringing cell phones, discs, walkmans, iPods, or CDs to school. Confiscated items will not be returned.</h6>
             <h6>On occasions when it is essential to bring a mobile phone to school, it must be handed over to the school office at the beginning of the day.</h6>

            <div class="lightYellowBtn">
                <a href="#">Begin your Chapter</a>
            </div>
        </div>
    </section>
    <div class="overlay-wave-img">
        <img src="<?= base_url('images/statutory/compliance-details.png') ?>" class="img-fluid"
            alt="Teacher's Discussion">
    </div>
    <!-- Section Menus -->

    <!-- Policys -->
    <section class="container-space white-bgImg ptb-80" id="guidelines">
        <div class="row m-0 w100">
            <div class="col-12 col-md-12 col-lg-12 col-xl-6 p-0">
                <div class="cardWith-under-info">
                    <div class="sectionTitle-blue">
                        <h3>Guidelines <span>For Parents</span></h3>
                    </div>
                    <img src="<?= base_url('images/facilities/extra-curicular-1.jpg') ?>" class="img-fluid w100"
                        alt="Sir Mutha Logo">
                    <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna</h6>
                    <div class="blueBtn-medium">
                        <a href="#">Know More</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-12 col-lg-12 col-xl-6 p-0">
                <div class="cardWith-under-info">
                    <div class="sectionTitle-blue">
                        <h3>Attendence & <span>Leave Policy</span></h3>
                    </div>
                    <img src="<?= base_url('images/facilities/extra-curicular-1.jpg') ?>" class="img-fluid w100"
                        alt="Sir Mutha Logo">
                    <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna</h6>
                    <div class="blueBtn-medium">
                        <a href="#">Know More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Policys -->

    <section class="container-space linenWhite-bgImg ptb-80" id="">
        <div class="mt-50">
            <div class="row m-0 w100">
                <div class="col-12 col-md-6 col-lg-4 col-xl-4 p-0">
                    <div class="cardWith-under-info-center">
                        <img src="<?= base_url('images/statutory/code-of-conduct.png') ?>" class="img-fluid w100"
                            alt="Sir Mutha Logo">
                        <div class="sectionSubTitle-blue">
                            <h4>code of <span>Conduct</span></h4>
                        </div>
                        <div class="card-under-line">
                            <hr>
                        </div>
                        <div class="blueBtn-medium">
                            <a href="#">Know More</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 col-xl-4 p-0">
                    <div class="cardWith-under-info-center">
                        <img src="<?= base_url('images/statutory/rules-and-regulations.png') ?>" class="img-fluid w100"
                            alt="Sir Mutha Logo">
                        <div class="sectionSubTitle-blue">
                            <h4>Rules & <span>Regulations</span></h4>
                        </div>
                        <div class="card-under-line">
                            <hr>
                        </div>
                        <div class="blueBtn-medium">
                            <a href="#">Know More</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 col-xl-4 p-0">
                    <div class="cardWith-under-info-center">
                        <img src="<?= base_url('images/statutory/child-support-policy.png') ?>" class="img-fluid w100"
                            alt="Sir Mutha Logo">
                        <div class="sectionSubTitle-blue">
                            <h4>Child <span>Support Policy</span></h4>
                        </div>
                        <div class="card-under-line">
                            <hr>
                        </div>
                        <div class="blueBtn-medium">
                            <a href="#">Know More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>